import mysql.connector


conne = mysql.connector.connect(
     host = 'localhost',
     user = 'root',
     password = 'x',
     database = 'labo_db'
)

cursor = conne.cursor()



sqlDadi = """ INSERT INTO DadiLabo(patient_firstname , patient_lastname , patient_number)
               VALUES(%s,%s,%s) 
                """

dadipatient = [("mohammed" , "khelfouni" , "12345")]

try:
    cursor.executemany(sqlDadi, dadipatient)
    #connection.commit()
except mysql.connector.IntegrityError:
    print("Patient already exists!")


cursor.execute("SELECT * FROM DadiLabo")
for row in cursor.fetchall():
    print(row)

print("\nABDERRAHMEN\n")

new_name = "Abderrahmen"

sqladd = f"""  CREATE TABLE IF NOT EXISTS {new_name}(
               id INT PRIMARY KEY AUTO_INCREMENT ,
               patient_firstnameA VARCHAR(50),
               patient_lastnameA VARCHAR(50),
               patient_id VARCHAR(20) UNIQUE 
               );    
"""

cursor.execute(sqladd)

sql = f"""  INSERT INTO {new_name}(patient_firstnameA , patient_lastnameA , patient_id) 
            VALUES (%s , %s  , %s ) 
          """
new_patient = [ ("dahmen" , "el_harrachi"  , "2222223" ) ]

try :
    cursor.executemany(sql,new_patient)
except mysql.connector.IntegrityError:
    print("user exist")


cursor.execute(f"SELECT * FROM {new_name}")

for row in cursor.fetchall():
    print(row)


from SqlConnection import cursor, connection
from UsufulFunctions import *
from DentistClass import addToFile

class Patient:

    def AddPatient(self):
        first_name, last_name = Get_names()

        # Check if patient number exists
        while True:
            number = Get_ID()
            cursor.execute("SELECT COUNT(*) FROM Patient WHERE patient_number = %s", (number,))
            exist = cursor.fetchone()[0]
            if exist > 0:
                print("User already exists")
            else:
                break

        # Get choice and price
        choice, price = self.Get_Patient_Choice()
        date = Get_Date()

        # Input khalsa
        while True:
            khalsa = input("Did the patient khelsek? (yes/no) ").lower()
            if khalsa in ['yes', 'no']:
                break
        khalsa_str = 'yes' if khalsa == 'yes' else 'no'

        # Input versa if khalsa is no
        versa = 0
        if khalsa_str == 'no':
            while True:
                Versa = input("Did the patient versa drahem? (yes/no) ").lower()
                if Versa in ['yes', 'no']:
                    break
            if Versa == 'yes':
                while True:
                    try:
                        versa = float(input("How much? "))
                        if versa < 0 or versa > price:
                            raise ValueError("Invalid amount")
                        break
                    except ValueError as e:
                        print(e)

        b9aw = price - versa if khalsa_str == 'no' else 0
        patient_infos = (first_name, last_name, number, choice, date, False, khalsa_str, versa, b9aw)

        # Insert into Patient table
        cursor.execute("""
            INSERT INTO Patient(
                patient_firstname, patient_lastname, patient_number,
                T_ype , la_date, finished, khalsa, versa, b9aw
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, patient_infos)
        connection.commit()

        # Insert into Khedma table
        khedma_infos = (last_name, price, date, 'NO', number, 'no', khalsa_str)
        cursor.execute("""
            INSERT INTO Khedma(
                khedman, khedma_price, khedma_date,
                khedma_dentist, khedma_patient, khedma_wajda, khedma_khalsa
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, khedma_infos)
        connection.commit()

    def Get_Patient_Choice(self):
        choice, price = Get_Choice()
        return choice, price